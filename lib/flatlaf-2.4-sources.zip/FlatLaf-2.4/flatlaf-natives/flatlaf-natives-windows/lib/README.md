Contains libraries used to compile FlatLaf Windows 10 native libraries (DLLs).

- `jawt-x86.lib` is `<jdk>/lib/jawt.lib` from AdoptOpenJDK jdk8u282-b08 32-bit,
  which is required to build 32-bit DLL
- `jawt-x86_64.lib` is `<jdk>/lib/jawt.lib` from AdoptOpenJDK jdk8u282-b08
  64-bit, which is required to build 64-bit DLL
