legacy-jgraph5
==============

The JGraph 5 legacy codebase.

DO NOT use this project for starting a new project unless you have a really good reason to. Development on the project 
stopped in 2009, we don't support it and only make updates for critical issues (which there has only been 1 in the 
last 4 years). Do not raise issues on it, they will be deleted. If you wish to fork and maintain the project, you are 
welcome to.

When we finished development in 2009, we were building with JDK 1.4. Any new builds will use Java 6, since we don't 
have a JDK 1.4 environment available. You would be recommended to build jars yourself from the source code.
